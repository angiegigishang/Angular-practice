export * from './image-slider.component';
